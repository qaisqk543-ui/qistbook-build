allprojects {
    repositories {
        maven {
            url = uri("http://127.0.0.1:3133/")
            isAllowInsecureProtocol = true
        }
        maven {
            url = uri("http://127.0.0.1:3133/")
            isAllowInsecureProtocol = true
        }
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
