@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
echo ========================================
echo  QistBook - Automatic APK Builder
echo ========================================
echo.
echo Ye script sab kuch KHUD karegi.
echo Aap ko kuch nahi karna, sirf intezar karna hai.
echo.
echo Pehli dafa 15-20 minute lag sakte hain
echo (internet se download hoga).
echo.
echo Shuru karne ke liye koi bhi key dabao...
pause >nul

:: Check for admin (not strictly needed but helpful)
:: Step 1: Flutter
if not exist "%~dp0flutter\bin\flutter.bat" (
    echo.
    echo [1/5] Flutter download ho rahi hai...
    echo Ye sab se bara download hai (700MB).
    echo Intezar karo, band mat karna!
    echo.
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.13.9-stable.zip' -OutFile '%~dp0flutter.zip'"
    if not exist "%~dp0flutter.zip" (
        echo.
        echo ERROR: Flutter download nahi hui!
        echo Apna internet check karo aur dobara chalao.
        echo.
        pause
        exit /b 1
    )
    echo Download ho gayi! Ab extract ho rahi hai...
    powershell -Command "Expand-Archive -Path '%~dp0flutter.zip' -DestinationPath '%~dp0' -Force"
    del "%~dp0flutter.zip"
    if not exist "%~dp0flutter\bin\flutter.bat" (
        echo ERROR: Flutter extract nahi hui! Dobara chalao.
        pause
        exit /b 1
    )
    echo Flutter tayyar!
) else (
    echo [1/5] Flutter pehle se maujood hai.
)

set "FLUTTER=%~dp0flutter\bin\flutter.bat"

:: Step 2: Android SDK
if not exist "%~dp0android-sdk\cmdline-tools\latest\bin\sdkmanager.bat" (
    echo.
    echo [2/5] Android SDK download ho raha hai...
    mkdir "%~dp0android-sdk\cmdline-tools" 2>nul
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/commandlinetools-win-9477386_latest.zip' -OutFile '%~dp0cmdtools.zip'"
    if not exist "%~dp0cmdtools.zip" (
        echo ERROR: Android SDK download nahi hua! Internet check karo.
        pause
        exit /b 1
    )
    powershell -Command "Expand-Archive -Path '%~dp0cmdtools.zip' -DestinationPath '%~dp0android-sdk\cmdline-tools' -Force"
    del "%~dp0cmdtools.zip"
    if exist "%~dp0android-sdk\cmdline-tools\cmdline-tools" (
        ren "%~dp0android-sdk\cmdline-tools\cmdline-tools" latest
    )
    echo Android SDK tayyar!
) else (
    echo [2/5] Android SDK pehle se maujood hai.
)

set "ANDROID_HOME=%~dp0android-sdk"
set "ANDROID_SDK_ROOT=%~dp0android-sdk"
set "PATH=%~dp0flutter\bin;%~dp0android-sdk\cmdline-tools\latest\bin;%~dp0android-sdk\platform-tools;%PATH%"

:: Step 3: Android packages
echo.
echo [3/5] Android ka samaan install ho raha hai...
echo (ye thora waqt lega, band mat karna)
(for /l %%i in (1,1,20) do echo y) | "%~dp0android-sdk\cmdline-tools\latest\bin\sdkmanager.bat" --licenses >nul 2>&1
"%~dp0android-sdk\cmdline-tools\latest\bin\sdkmanager.bat" "platform-tools" "platforms;android-33" "build-tools;33.0.2" >nul 2>&1
echo Android packages tayyar!

:: Step 4: Dependencies
echo.
echo [4/5] App ka samaan download ho raha hai...
cd /d "%~dp0kistbook"
call "%FLUTTER%" --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Flutter nahi chal rahi!
    pause
    exit /b 1
)
call "%FLUTTER%" pub get
if %errorlevel% neq 0 (
    echo ERROR: Dependencies download nahi huin! Internet check karo.
    pause
    exit /b 1
)
echo Dependencies tayyar!

:: Step 5: Build
echo.
echo [5/5] APK ban rahi hai...
echo Ye akhri step hai, 5-10 minute lag sakte hain.
echo Band mat karna!
echo.
call "%FLUTTER%" build apk --release

if %errorlevel% equ 0 (
    echo.
    echo ========================================
    echo  MUBARAK! APK TAYYAR HAI!
    echo ========================================
    echo.
    echo APK is jagah hai:
    echo %~dp0kistbook\build\app\outputs\flutter-apk\app-release.apk
    echo.
    echo Is file ko apne mobile me bhejo
    echo (WhatsApp ya USB se) aur install kar lo.
    echo App ka naam "QistBook" hoga.
    echo.
    :: Try to open the folder
    explorer "%~dp0kistbook\build\app\outputs\flutter-apk" 2>nul
) else (
    echo.
    echo ========================================
    echo  ERROR: APK nahi ban saki!
    echo ========================================
    echo.
    echo Upar jo error likha hai uska screenshot
    echo lekar bhejo, main dekh lunga.
    echo.
)
echo.
pause
